from django.shortcuts import render
from testapp.form import employeeform
from testapp.models import employee

# Create your views here.
def employee_view(request):
    # employee=employee.objects.all()
    form=employeeform()
    if request.method=='POST':
        form=employeeform(request.POST)
        if form.is_valid():
            form.save(commit=True)
    # my_dict={'employee':employee}
    # return render(request,'testapp/login.html',context=my_dict)
    return render(request,'testapp/login.html',{'form':form})

