from django import forms
# from testapp.models import employee

class employeeform(forms.Form):
    username=forms.CharField(max_length=30)
    password=forms.IntegerField()